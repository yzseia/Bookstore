package com.example.recipeapp.Models;

public class Measures {
    public Us us;
    public Metric metric;
}
